﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameSlot.Types
{
    public class SteamUser
    {
        public string Name;
        public string Avatar;
        public ulong SteamID;
        public string ProfileURL;
    }
}
